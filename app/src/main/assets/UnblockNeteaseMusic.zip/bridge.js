#!/usr/bin/env node

require('./src/bootstrap')('bridge');
